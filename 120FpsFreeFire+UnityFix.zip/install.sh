SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
  ui_print "Free Fire (120fps)"
  ui_print
  ui_print "Thanks to @LeanHijosdesusMadres for unityfix and @Ribeiro "
  ui_print
  ui_print "Que bomba hein🤗"
  ui_print
sleep 0.5
  ui_print "Celular: $(getprop ro.product.model) "
  ui_print
sleep 0.5
  ui_print "Marca: $(getprop ro.product.system.brand) "
  ui_print
sleep 0.5
  ui_print "Modelo: $(getprop ro.build.product) "
  ui_print
sleep 0.5
  ui_print "Kernel: $(uname -r) "
  ui_print
sleep 0.5
  ui_print "Placa: $(getprop ro.product.board) "
  ui_print
  
}

MOD_EXTRACT() {
 unzip -o "$ZIPFILE" system/* -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}